"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { preguntas, letras } from "../data/preguntas"
import type { EstadoLetra, PuntajeJugador } from "../types/game"

export function useRoscoGame() {
  const [nombreJugador, setNombreJugador] = useState("")
  const [juegoIniciado, setJuegoIniciado] = useState(false)
  const [letraActual, setLetraActual] = useState("")
  const [aciertos, setAciertos] = useState(0)
  const [errores, setErrores] = useState(0)
  const [tiempo, setTiempo] = useState(180)
  const [estadosLetras, setEstadosLetras] = useState<Record<string, EstadoLetra>>({})
  const [pasadas, setPasadas] = useState<string[]>([])
  const [inRevancha, setInRevancha] = useState(false)
  const [preguntaActual, setPreguntaActual] = useState("Presioná una letra para comenzar")
  const [respuesta, setRespuesta] = useState("")
  const [ranking, setRanking] = useState<PuntajeJugador[]>([])

  const inicioTiempoRef = useRef<Date | null>(null)
  const intervaloRef = useRef<NodeJS.Timeout | null>(null)

  const cargarRanking = useCallback(() => {
    if (typeof window !== "undefined") {
      const datos = JSON.parse(localStorage.getItem("rankingRosco") || "[]")
      setRanking(datos.reverse())
    }
  }, [])

  useEffect(() => {
    cargarRanking()
  }, [cargarRanking])

  const iniciarTemporizador = useCallback(() => {
    if (intervaloRef.current) return

    intervaloRef.current = setInterval(() => {
      setTiempo((prev) => {
        if (prev <= 1) {
          if (intervaloRef.current) {
            clearInterval(intervaloRef.current)
            intervaloRef.current = null
          }
          setPreguntaActual("⏱ ¡Tiempo terminado!")

          setTimeout(() => {
            if (!inRevancha && pasadas.length > 0) {
              iniciarRevancha()
            } else {
              guardarPuntaje()
            }
          }, 1000)

          return 0
        }
        return prev - 1
      })
    }, 1000)
  }, [inRevancha, pasadas.length])

  const iniciarJuego = useCallback((nombre: string) => {
    if (!nombre.trim()) return false

    setNombreJugador(nombre)
    inicioTiempoRef.current = new Date()
    setJuegoIniciado(true)
    setAciertos(0)
    setErrores(0)
    setTiempo(180)
    setInRevancha(false)
    setPasadas([])
    setEstadosLetras({})
    setRespuesta("")

    if (intervaloRef.current) {
      clearInterval(intervaloRef.current)
      intervaloRef.current = null
    }

    // Seleccionar primera letra
    setTimeout(() => {
      seleccionarLetra("A")
    }, 100)

    return true
  }, [])

  const seleccionarLetra = useCallback(
    (letra: string) => {
      if (estadosLetras[letra] === "usada" || estadosLetras[letra] === "acierto" || estadosLetras[letra] === "error") {
        return
      }

      iniciarTemporizador()
      setLetraActual(letra)

      if (preguntas[letra]) {
        setPreguntaActual(preguntas[letra].pregunta)
        setRespuesta("")
      }
    },
    [estadosLetras, iniciarTemporizador],
  )

  const verificarRespuesta = useCallback(() => {
    if (!letraActual) return

    const respuestaLimpia = respuesta.trim().toLowerCase()
    const correcta = preguntas[letraActual]?.respuesta.toLowerCase()

    if (respuestaLimpia === correcta) {
      setAciertos((prev) => prev + 1)
      setEstadosLetras((prev) => ({ ...prev, [letraActual]: "acierto" }))
    } else {
      setErrores((prev) => prev + 1)
      setEstadosLetras((prev) => ({ ...prev, [letraActual]: "error" }))
    }

    setLetraActual("")
    setRespuesta("")
    avanzarAutomaticamente()
  }, [letraActual, respuesta])

  const pasapalabra = useCallback(() => {
    if (!letraActual) return

    setPasadas((prev) => [...prev, letraActual])
    setEstadosLetras((prev) => ({ ...prev, [letraActual]: "pasapalabra" }))
    setLetraActual("")
    setRespuesta("")
    avanzarAutomaticamente()
  }, [letraActual])

  const avanzarAutomaticamente = useCallback(() => {
    setTimeout(() => {
      const siguiente = letras.find(
        (letra) =>
          !estadosLetras[letra] ||
          (estadosLetras[letra] !== "usada" && estadosLetras[letra] !== "acierto" && estadosLetras[letra] !== "error"),
      )

      if (siguiente) {
        seleccionarLetra(siguiente)
      } else {
        if (intervaloRef.current) {
          clearInterval(intervaloRef.current)
          intervaloRef.current = null
        }

        setTimeout(() => {
          if (!inRevancha && pasadas.length > 0) {
            iniciarRevancha()
          } else {
            guardarPuntaje()
          }
        }, 300)
      }
    }, 100)
  }, [estadosLetras, inRevancha, pasadas.length, seleccionarLetra])

  const iniciarRevancha = useCallback(() => {
    setInRevancha(true)
    const letrasPasadas = [...pasadas]
    setPasadas([])

    const nuevosEstados = { ...estadosLetras }
    letrasPasadas.forEach((letra) => {
      delete nuevosEstados[letra]
    })
    setEstadosLetras(nuevosEstados)

    avanzarAutomaticamente()
  }, [pasadas, estadosLetras, avanzarAutomaticamente])

  const guardarPuntaje = useCallback(() => {
    if (!inicioTiempoRef.current) return

    const fin = new Date()
    const tiempoTranscurrido = Math.round((fin.getTime() - inicioTiempoRef.current.getTime()) / 1000)

    const nuevoPuntaje: PuntajeJugador = {
      nombre: nombreJugador,
      aciertos,
      errores,
      tiempo: tiempoTranscurrido,
      fecha: fin.toLocaleString(),
    }

    if (typeof window !== "undefined") {
      const historial = JSON.parse(localStorage.getItem("rankingRosco") || "[]")
      historial.push(nuevoPuntaje)
      localStorage.setItem("rankingRosco", JSON.stringify(historial))
      cargarRanking()
    }

    alert(`Puntaje guardado. Aciertos: ${aciertos}, Errores: ${errores}, Tiempo: ${tiempoTranscurrido} segundos`)
  }, [nombreJugador, aciertos, errores, cargarRanking])

  return {
    nombreJugador,
    juegoIniciado,
    letraActual,
    aciertos,
    errores,
    tiempo,
    estadosLetras,
    preguntaActual,
    respuesta,
    ranking,
    setRespuesta,
    iniciarJuego,
    seleccionarLetra,
    verificarRespuesta,
    pasapalabra,
  }
}
