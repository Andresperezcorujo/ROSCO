"use client"

import { LetraRosco } from "./LetraRosco"
import { letras } from "../data/preguntas"
import type { EstadoLetra } from "../types/game"

interface RoscoProps {
  estadosLetras: Record<string, EstadoLetra>
  letraActual: string
  onLetraClick: (letra: string) => void
}

export function Rosco({ estadosLetras, letraActual, onLetraClick }: RoscoProps) {
  const calcularPosicion = (index: number) => {
    const angle = (360 / letras.length) * index
    const radius = 120
    const x = 130 + radius * Math.cos((angle - 90) * (Math.PI / 180))
    const y = 130 + radius * Math.sin((angle - 90) * (Math.PI / 180))
    return { x, y }
  }

  return (
    <div className="relative w-80 h-80 mx-auto border border-gray-300 rounded-full bg-gradient-to-br from-blue-100 to-purple-100">
      {letras.map((letra, index) => (
        <LetraRosco
          key={letra}
          letra={letra}
          estado={estadosLetras[letra] || "normal"}
          posicion={calcularPosicion(index)}
          onClick={() => onLetraClick(letra)}
          isActive={letra === letraActual}
        />
      ))}
    </div>
  )
}
