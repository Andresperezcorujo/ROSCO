"use client"

import type { EstadoLetra } from "../types/game"

interface LetraRoscoProps {
  letra: string
  estado: EstadoLetra
  posicion: { x: number; y: number }
  onClick: () => void
  isActive: boolean
}

export function LetraRosco({ letra, estado, posicion, onClick, isActive }: LetraRoscoProps) {
  const getEstiloLetra = () => {
    const baseClasses =
      "absolute w-10 h-10 rounded-full text-center leading-10 font-bold cursor-pointer transition-all duration-300 border-2"

    switch (estado) {
      case "acierto":
        return `${baseClasses} bg-green-500 text-white border-green-600`
      case "error":
        return `${baseClasses} bg-red-500 text-white border-red-600`
      case "pasapalabra":
        return `${baseClasses} bg-lime-400 text-white border-lime-500`
      case "usada":
        return `${baseClasses} bg-gray-300 text-gray-500 opacity-50 pointer-events-none border-gray-400`
      default:
        return `${baseClasses} bg-white text-blue-500 border-blue-300 hover:scale-110 ${
          isActive ? "ring-4 ring-yellow-400 scale-110" : ""
        }`
    }
  }

  return (
    <div
      className={getEstiloLetra()}
      style={{
        left: `${posicion.x}px`,
        top: `${posicion.y}px`,
      }}
      onClick={onClick}
    >
      {letra}
    </div>
  )
}
