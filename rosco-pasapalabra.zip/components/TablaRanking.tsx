import type { PuntajeJugador } from "../types/game"

interface TablaRankingProps {
  ranking: PuntajeJugador[]
}

export function TablaRanking({ ranking }: TablaRankingProps) {
  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold text-center mb-4 text-white">🏆 Ranking Histórico</h2>
      <div className="overflow-x-auto">
        <table className="mx-auto border-collapse bg-white rounded-lg shadow-lg overflow-hidden">
          <thead>
            <tr className="bg-indigo-600 text-white">
              <th className="border border-gray-300 px-4 py-2">Nombre</th>
              <th className="border border-gray-300 px-4 py-2">Aciertos</th>
              <th className="border border-gray-300 px-4 py-2">Errores</th>
              <th className="border border-gray-300 px-4 py-2">Tiempo (s)</th>
              <th className="border border-gray-300 px-4 py-2">Fecha</th>
            </tr>
          </thead>
          <tbody>
            {ranking.map((jugador, index) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="border border-gray-300 px-4 py-2">{jugador.nombre}</td>
                <td className="border border-gray-300 px-4 py-2 text-center">{jugador.aciertos}</td>
                <td className="border border-gray-300 px-4 py-2 text-center">{jugador.errores}</td>
                <td className="border border-gray-300 px-4 py-2 text-center">{jugador.tiempo}</td>
                <td className="border border-gray-300 px-4 py-2 text-center text-sm">{jugador.fecha}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
