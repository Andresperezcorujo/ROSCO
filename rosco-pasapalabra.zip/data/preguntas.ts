import type { Pregunta } from "../types/game"

export const preguntas: Record<string, Pregunta> = {
  A: { pregunta: "Empieza con A: País del nacimiento del papa Francisco.", respuesta: "argentina" },
  B: { pregunta: "Empieza con B: Movimiento artístico europeo.", respuesta: "barroco" },
  C: {
    pregunta:
      "Empieza con C: El uso de la fuerza o de intimidación para forzar una acción o para modificar o restringir la conducta.",
    respuesta: "coercion",
  },
  D: { pregunta: "Empieza con D: 'Pienso luego existo'.", respuesta: "descartes" },
  E: { pregunta: "Empieza con E: Que provoca vergüenza.", respuesta: "embarazoso" },
  F: {
    pregunta: "Empieza con F: Género musical gitano, que nació y se desarrolló en Andalucía.",
    respuesta: "flamenco",
  },
  G: {
    pregunta: "Empieza con G: Persona encargada de escribir un guion o libreto para cine, radio, televisión, etc.",
    respuesta: "guionista",
  },
  H: { pregunta: "Empieza con H: Este día.", respuesta: "hoy" },
  I: { pregunta: "Empieza con I: Falta de conocimiento.", respuesta: "ignorancia" },
  J: { pregunta: "Empieza con J: Actividad lúdica.", respuesta: "juego" },
  K: { pregunta: "Empieza con K: Arte marcial.", respuesta: "karate" },
  L: {
    pregunta: "Empieza con L: Lugar del 'Infierno de Dante' donde están los virtuosos no bautizados.",
    respuesta: "limbo",
  },
  M: {
    pregunta: "Empieza con M: Considerar indigno o inferior; no dar el aprecio o valor que se merece algo o a alguien.",
    respuesta: "menospreciar",
  },
  N: { pregunta: "Empieza con N: Deidad femenina de la naturaleza en mitología.", respuesta: "ninfa" },
  Ñ: { pregunta: "Contiene Ñ: País de Europa.", respuesta: "españa" },
  O: { pregunta: "Empieza con O: Que procede de, o tiene su origen en, el lugar que se indica.", respuesta: "oriundo" },
  P: { pregunta: "Empieza con P: País sudamericano cuya capital es Lima.", respuesta: "peru" },
  Q: { pregunta: "Empieza con Q: Hidalgo protagonista de la novela de Cervantes.", respuesta: "quijote" },
  R: {
    pregunta: "Empieza con R: Movimiento cultural surgido en Europa durante los siglos XV y XVI.",
    respuesta: "renacimiento",
  },
  S: { pregunta: "Empieza con S: Criatura mitológica con torso de mujer y cola de pez.", respuesta: "sirena" },
  T: { pregunta: "Empieza con T: El espacio que media de un paraje a otro.", respuesta: "travesia" },
  U: { pregunta: "Empieza con U: Institución académica.", respuesta: "universidad" },
  V: { pregunta: "Empieza con V: Que tiene apariencia de verdadero.", respuesta: "verosimil" },
  W: { pregunta: "Empieza con W: Tecnología de conexión inalámbrica.", respuesta: "wifi" },
  X: { pregunta: "Contiene X: Prueba médica que permite ver el interior del cuerpo.", respuesta: "rayos x" },
  Y: { pregunta: "Empieza con Y: Juguete que sube y baja con un hilo.", respuesta: "yoyo" },
  Z: { pregunta: "Empieza con Z: Sonido que hacen algunos insectos como el mosquito.", respuesta: "zumbido" },
}

export const letras = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ".split("")
