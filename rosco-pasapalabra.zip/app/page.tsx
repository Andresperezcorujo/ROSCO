"use client"

import type React from "react"

import { useState } from "react"
import { useRoscoGame } from "../hooks/useRoscoGame"
import { Rosco } from "../components/Rosco"
import { TablaRanking } from "../components/TablaRanking"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"

export default function RoscoPasapalabra() {
  const [nombreInput, setNombreInput] = useState("")
  const {
    juegoIniciado,
    letraActual,
    aciertos,
    errores,
    tiempo,
    estadosLetras,
    preguntaActual,
    respuesta,
    ranking,
    setRespuesta,
    iniciarJuego,
    seleccionarLetra,
    verificarRespuesta,
    pasapalabra,
  } = useRoscoGame()

  const handleIniciarJuego = () => {
    if (iniciarJuego(nombreInput)) {
      setNombreInput("")
    } else {
      alert("Por favor ingresá tu nombre")
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      if (!juegoIniciado) {
        handleIniciarJuego()
      } else {
        verificarRespuesta()
      }
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 to-purple-600 text-center font-sans p-4">
      <h1 className="text-4xl md:text-5xl font-bold text-white mb-8 drop-shadow-lg">Rosco - Pasapalabra</h1>

      {!juegoIniciado ? (
        <Card className="max-w-md mx-auto">
          <CardContent className="p-6">
            <div className="space-y-4">
              <Input
                type="text"
                placeholder="Tu nombre"
                value={nombreInput}
                onChange={(e) => setNombreInput(e.target.value)}
                onKeyPress={handleKeyPress}
                className="text-center"
              />
              <Button onClick={handleIniciarJuego} className="w-full">
                Iniciar juego
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          <Rosco estadosLetras={estadosLetras} letraActual={letraActual} onLetraClick={seleccionarLetra} />

          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-6 space-y-4">
              <p className="text-lg font-medium">{preguntaActual}</p>

              <div className="flex gap-2">
                <Input
                  type="text"
                  placeholder="Escribí tu respuesta"
                  value={respuesta}
                  onChange={(e) => setRespuesta(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="flex-1"
                />
                <Button onClick={verificarRespuesta}>Responder</Button>
                <Button onClick={pasapalabra} variant="outline">
                  Pasapalabra
                </Button>
              </div>

              <div className="flex justify-between items-center text-sm">
                <span>
                  Aciertos: <strong className="text-green-600">{aciertos}</strong>
                </span>
                <span className="text-lg font-bold">⏱ Tiempo: {tiempo}s</span>
                <span>
                  Errores: <strong className="text-red-600">{errores}</strong>
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <TablaRanking ranking={ranking} />
    </div>
  )
}
