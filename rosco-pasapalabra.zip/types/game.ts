export interface Pregunta {
  pregunta: string
  respuesta: string
}

export interface PuntajeJugador {
  nombre: string
  aciertos: number
  errores: number
  tiempo: number
  fecha: string
}

export type EstadoLetra = "normal" | "acierto" | "error" | "pasapalabra" | "usada"
